const test=require('node:test');
const assert=require('node:assert/strict');
const request=require('http').request;
let server, base;
test('health endpoint responds', async t=>{
  const app=require('../src/server');
  server=app.listen(0);
  await new Promise(r=>server.once('listening',r));
  base=`http://127.0.0.1:${server.address().port}`;
  const data=await fetch(base+'/health').then(r=>r.json());
  assert.equal(data.status,'ok');
  t.after(()=>server.close());
});
test('unknown API route returns JSON 404', async()=>{
  const r=await fetch(base+'/achievements/nope/nope');
  assert.equal(r.status,404);
  const data=await r.json();
  assert.equal(data.success,false);
});
