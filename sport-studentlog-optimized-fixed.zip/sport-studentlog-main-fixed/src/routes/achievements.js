const express = require('express');
const db = require('../db');
const { authRequired } = require('../middleware/auth');

const router = express.Router();

const VALID_SPORTS = [
  'Cricket','Football','100m Dash','500m Dash','Shot Put',
  'Long Jump','Chess','Carrom','Volleyball','Hockey',
];
const VALID_LEVELS = [
  'School Level','College Level','Inter-College','District Level',
  'State Level','National Level','International Level',
];
const VALID_CATEGORIES = ['Individual','Team','Mixed'];
const MAX = { student_name:100, roll_number:30, batch_year:20, class:50, achievement:300, position:80, score:100, event_name:200, event_date:10, description:2000 };

function clean(value) { return typeof value === 'string' ? value.trim() : ''; }
function validatePayload(b) {
  const data = {
    student_name: clean(b.student_name), roll_number: clean(b.roll_number).toUpperCase(),
    batch_year: clean(b.batch_year), class: clean(b.class), sport: clean(b.sport),
    category: clean(b.category), achievement: clean(b.achievement), position: clean(b.position),
    score: clean(b.score), event_name: clean(b.event_name), event_date: clean(b.event_date),
    level: clean(b.level), description: clean(b.description)
  };
  for (const f of ['student_name','roll_number','class','sport','category','achievement','level']) {
    if (!data[f]) return { error: `${f.replace(/_/g,' ')} is required` };
  }
  if (!/^[A-Z0-9]{15}$/.test(data.roll_number)) return { error: 'Registration number must be exactly 15 letters/numbers' };
  if (!VALID_SPORTS.includes(data.sport)) return { error: 'Invalid sport' };
  if (!VALID_LEVELS.includes(data.level)) return { error: 'Invalid level' };
  if (!VALID_CATEGORIES.includes(data.category)) return { error: 'Invalid category' };
  if (data.event_date && !/^\d{4}-\d{2}-\d{2}$/.test(data.event_date)) return { error: 'Invalid event date' };
  for (const [f, max] of Object.entries(MAX)) if (data[f].length > max) return { error: `${f.replace(/_/g,' ')} is too long (max ${max} characters)` };
  return { data };
}

// ── GET /achievements ──
router.get('/', (req, res, next) => {
  try {
    const { student_name, sport, level, class: cls } = req.query;
    let sql = 'SELECT * FROM achievements WHERE 1=1';
    const params = [];

    if (student_name) {
      sql += ' AND (student_name LIKE ? OR roll_number LIKE ?)';
      const q = `%${student_name}%`;
      params.push(q, q);
    }
    if (sport)  { sql += ' AND sport = ?'; params.push(sport); }
    if (level)  { sql += ' AND level = ?'; params.push(level); }
    if (cls)    { sql += ' AND class LIKE ?'; params.push(`%${cls}%`); }

    sql += ' ORDER BY id DESC';
    const rows = db.prepare(sql).all(...params);
    res.json({ success: true, count: rows.length, data: rows });
  } catch (err) { next(err); }
});

// ── GET /achievements/:id ──
router.get('/:id', (req, res, next) => {
  try {
    const row = db.prepare('SELECT * FROM achievements WHERE id = ?').get(Number(req.params.id));
    if (!row) return res.status(404).json({ success: false, error: 'Not found' });
    res.json({ success: true, data: row });
  } catch (err) { next(err); }
});

// ── POST /achievements ──
router.post('/', authRequired, (req, res, next) => {
  try {
    const validation = validatePayload(req.body || {});
    if (validation.error) return res.status(400).json({ success: false, error: validation.error });
    const b = validation.data;

    const result = db.prepare(`
      INSERT INTO achievements
        (student_name, roll_number, batch_year, class, sport, category,
         achievement, position, score, event_name, event_date, level, description, created_by)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)
    `).run(
      b.student_name, b.roll_number, b.batch_year, b.class, b.sport, b.category,
      b.achievement, b.position, b.score, b.event_name, b.event_date,
      b.level, b.description, req.user.reg_number
    );

    const row = db.prepare('SELECT * FROM achievements WHERE id = ?').get(result.lastInsertRowid);
    res.status(201).json({ success: true, message: 'Achievement recorded!', data: row });
  } catch (err) { next(err); }
});

// ── PUT /achievements/:id ──
router.put('/:id', authRequired, (req, res, next) => {
  try {
    const id = Number(req.params.id);
    if (!db.prepare('SELECT id FROM achievements WHERE id = ?').get(id))
      return res.status(404).json({ success: false, error: 'Not found' });

    const result = validatePayload(req.body || {});
    if (result.error) return res.status(400).json({ success: false, error: result.error });
    const b = result.data;

    db.prepare(`
      UPDATE achievements SET
        student_name=?, roll_number=?, batch_year=?, class=?, sport=?, category=?,
        achievement=?, position=?, score=?, event_name=?, event_date=?, level=?,
        description=?, updated_at=datetime('now')
      WHERE id=?
    `).run(
      b.student_name, b.roll_number, b.batch_year, b.class, b.sport, b.category,
      b.achievement, b.position, b.score, b.event_name, b.event_date,
      b.level, b.description, id
    );

    const row = db.prepare('SELECT * FROM achievements WHERE id = ?').get(id);
    res.json({ success: true, message: 'Updated', data: row });
  } catch (err) { next(err); }
});

// ── DELETE /achievements/:id ──
router.delete('/:id', authRequired, (req, res, next) => {
  try {
    const id = Number(req.params.id);
    if (!db.prepare('SELECT id FROM achievements WHERE id = ?').get(id))
      return res.status(404).json({ success: false, error: 'Not found' });

    db.prepare('DELETE FROM achievements WHERE id = ?').run(id);
    res.json({ success: true, message: 'Deleted' });
  } catch (err) { next(err); }
});

module.exports = router;
