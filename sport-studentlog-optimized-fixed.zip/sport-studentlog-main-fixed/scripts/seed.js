const bcrypt=require('bcrypt'); const db=require('../src/db');
const user=db.prepare('SELECT id FROM users WHERE reg_number=?').get('RA2111003010001');
if(!user){const hash=bcrypt.hashSync('Demo@1234',12); db.prepare('INSERT INTO users(name,reg_number,email,password_hash) VALUES(?,?,?,?)').run('Demo Student','RA2111003010001','demo@srmist.edu.in',hash);}
const createdBy='RA2111003010001';
const count=db.prepare('SELECT COUNT(*) c FROM achievements').get().c;
if(!count){const insert=db.prepare(`INSERT INTO achievements(student_name,roll_number,batch_year,class,sport,category,achievement,position,score,event_name,event_date,level,description,created_by) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)`);
[['Arjun Sharma','RA2111003010001','2022-2026','CSE-A','Cricket','Individual','Top scorer at Annual Sports Meet','1st Place / Gold','150 runs','Annual Sports Meet','2026-01-15','College Level','Outstanding batting performance',createdBy],
['Priya Singh','RA2111003010002','2022-2026','ECE-B','Chess','Individual','University Chess Championship','2nd Place / Silver','6/7','University Championship','2026-02-20','Inter-College','Strong tournament performance',createdBy]].forEach(r=>insert.run(...r));}
console.log('Seed complete. Demo login: RA2111003010001 / Demo@1234');
