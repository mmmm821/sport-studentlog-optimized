const fs=require('fs'),path=require('path'); const config=require('../src/config');
const db=require('../src/db'); db.close();
const file=path.resolve(config.db.path);
for(const suffix of ['','-shm','-wal']){try{fs.unlinkSync(file+suffix)}catch{}}
console.log('Database reset. Start the server to recreate the schema.');
