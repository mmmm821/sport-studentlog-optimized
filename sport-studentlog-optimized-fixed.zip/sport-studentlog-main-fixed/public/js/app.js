
'use strict';

const API = '';
const SPORTS = [
  ['Cricket','🏏'],['Football','⚽'],['100m Dash','🏃'],['500m Dash','🏃'],
  ['Shot Put','🥏'],['Long Jump','🦘'],['Chess','♟️'],['Carrom','🎯'],
  ['Volleyball','🏐'],['Hockey','🏑']
];
let token = localStorage.getItem('sportlog_token') || '';
let currentUser = null;
let achievements = [];
let toastTimer = null;

const $ = id => document.getElementById(id);
const escapeHtml = value => String(value ?? '').replace(/[&<>"']/g, c => ({
  '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'
}[c]));

function setToken(value) {
  token = value || '';
  if (token) localStorage.setItem('sportlog_token', token);
  else localStorage.removeItem('sportlog_token');
}

async function api(path, options = {}) {
  const headers = { ...(options.body ? {'Content-Type':'application/json'} : {}), ...(options.headers || {}) };
  if (token) headers.Authorization = `Bearer ${token}`;
  const response = await fetch(`${API}${path}`, {...options, headers});
  let payload = null;
  try { payload = await response.json(); } catch {}
  if (!response.ok) {
    if (response.status === 401 && token) {
      setToken('');
      currentUser = null;
      goto('screen-login');
    }
    throw new Error(payload?.error || `Request failed (${response.status})`);
  }
  return payload;
}

function showToast(message, error = false) {
  const el = $('toast');
  if (!el) return;
  el.textContent = message;
  el.className = error ? 'show err' : 'show';
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { el.className = ''; }, 3500);
}

function setBusy(button, busy, label) {
  if (!button) return;
  if (busy) {
    button.dataset.originalText = button.textContent;
    button.disabled = true;
    button.textContent = label || 'PLEASE WAIT…';
  } else {
    button.disabled = false;
    button.textContent = button.dataset.originalText || button.textContent;
  }
}

function goto(id) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  const target = $(id);
  if (target) target.classList.add('active');
  window.scrollTo({top:0, behavior:'smooth'});
}

async function showPortal() {
  goto('screen-portal');
  if (currentUser) {
    $('nav_name').textContent = currentUser.name;
    $('nav_reg').textContent = currentUser.reg_number;
  }
  showPortalTab('home');
  await Promise.allSettled([loadStats(), loadAchievements()]);
}

function showPortalTab(tab) {
  document.querySelectorAll('.psec').forEach(s => s.classList.remove('active'));
  document.querySelectorAll('.nav-tab').forEach(b => b.classList.toggle('active', b.dataset.tab === tab));
  const section = $(`psec-${tab}`);
  if (section) section.classList.add('active');
  if (tab === 'home') renderSportsGrid();
  if (tab === 'view') searchAchievements();
  if (tab === 'leaderboard') loadStats();
}

function togglePw(id, button) {
  const input = $(id);
  if (!input) return;
  input.type = input.type === 'password' ? 'text' : 'password';
  if (button) button.textContent = input.type === 'password' ? '👁' : '🙈';
}

function updateRegCounter() {
  const input = $('su_reg');
  if (!input) return;
  input.value = input.value.toUpperCase().replace(/\s/g,'').slice(0,15);
  $('reg_counter').textContent = `${input.value.length} / 15 characters`;
}

function validateEmailLive() {
  const email = $('su_email')?.value.trim().toLowerCase() || '';
  const hint = $('email_hint');
  if (!hint) return;
  const valid = /^[^\s@]+@srmist\.edu\.in$/i.test(email);
  hint.textContent = valid ? 'Valid SRMIST email' : 'Must end with @srmist.edu.in';
  hint.classList.toggle('err-msg', email.length > 0 && !valid);
}

function checkStrength() {
  const pw = $('su_pw')?.value || '';
  const fill = $('pw_fill');
  const label = $('pw_strength_label');
  if (!fill || !label) return;
  let score = 0;
  if (pw.length >= 8) score++;
  if (pw.length >= 12) score++;
  if (/[A-Z]/.test(pw)) score++;
  if (/[a-z]/.test(pw)) score++;
  if (/\d/.test(pw)) score++;
  if (/[^A-Za-z0-9]/.test(pw)) score++;
  const pct = Math.min(100, score * 16.67);
  fill.style.width = `${pct}%`;
  label.textContent = !pw ? 'Enter a password' : score <= 2 ? 'Weak' : score <= 4 ? 'Good' : 'Strong';
}

async function createAccount() {
  const button = $('btn_createacct');
  const body = {
    name: $('su_name').value.trim(),
    reg_number: $('su_reg').value.trim().toUpperCase(),
    email: $('su_email').value.trim().toLowerCase(),
    password: $('su_pw').value,
    confirm_password: $('su_pw2').value
  };
  if (!body.name || !body.reg_number || !body.email || !body.password || !body.confirm_password) {
    showToast('Please complete every field.', true); return;
  }
  setBusy(button, true);
  try {
    const data = await api('/auth/signup', {method:'POST', body:JSON.stringify(body)});
    setToken(data.token);
    currentUser = data.user;
    showToast('Account created successfully!');
    await showPortal();
  } catch (err) { showToast(err.message, true); }
  finally { setBusy(button, false); }
}

async function doLogin() {
  const button = document.querySelector('#screen-login .btn-primary');
  const body = {
    reg_number: $('li_reg').value.trim().toUpperCase(),
    password: $('li_pw').value
  };
  if (!body.reg_number || !body.password) {
    showToast('Enter your registration number and password.', true); return;
  }
  setBusy(button, true);
  try {
    const data = await api('/auth/login', {method:'POST', body:JSON.stringify(body)});
    setToken(data.token);
    currentUser = data.user;
    showToast('Welcome back!');
    await showPortal();
  } catch (err) { showToast(err.message, true); }
  finally { setBusy(button, false); }
}

async function restoreSession() {
  if (!token) { goto('screen-landing'); return; }
  try {
    const data = await api('/auth/me');
    currentUser = data.user;
    await showPortal();
  } catch {
    setToken('');
    goto('screen-landing');
  }
}

function logout() {
  setToken('');
  currentUser = null;
  achievements = [];
  $('li_pw').value = '';
  goto('screen-landing');
  showToast('You have been logged out.');
}

async function loadStats() {
  try {
    const {data} = await api('/stats');
    $('pStatTotal').textContent = data.totalAchievements;
    $('pStatStudents').textContent = data.totalStudents;
    renderBars('chartBySport', data.bySport);
    renderBars('chartByLevel', data.byLevel);
    renderWinners(data.recentWinners || []);
  } catch (err) {
    if ($('pStatTotal')) $('pStatTotal').textContent = '—';
    showToast(err.message, true);
  }
}

function renderBars(id, rows) {
  const container = $(id);
  if (!container) return;
  if (!rows?.length) {
    container.innerHTML = '<div class="empty-state"><p>No data available yet.</p></div>';
    return;
  }
  const max = Math.max(...rows.map(r => Number(r.count) || 0), 1);
  container.innerHTML = rows.map(r => `
    <div class="bar-row">
      <div class="bar-label">${escapeHtml(r.sport || r.level)}</div>
      <div class="bar-bg"><div class="bar-fill" style="width:${Math.max(8,(Number(r.count)/max)*100)}%">${Number(r.count)}</div></div>
    </div>`).join('');
}

function renderWinners(rows) {
  const el = $('winnersTable');
  if (!el) return;
  if (!rows.length) {
    el.innerHTML = '<div class="empty-state"><div class="empty-icon">🏅</div><p>No medal winners recorded yet.</p></div>';
    return;
  }
  el.innerHTML = `<div style="overflow-x:auto"><table class="winners-table">
    <thead><tr><th>#</th><th>Student</th><th>Sport</th><th>Achievement</th><th>Level</th></tr></thead>
    <tbody>${rows.map((r,i)=>`<tr>
      <td><span class="rank-badge ${i<3?`r${i+1}`:'rn'}">${i+1}</span></td>
      <td>${escapeHtml(r.student_name)}</td><td>${escapeHtml(r.sport)}</td>
      <td>${escapeHtml(r.position || r.achievement)}</td><td>${escapeHtml(r.level)}</td>
    </tr>`).join('')}</tbody></table></div>`;
}

function renderSportsGrid() {
  const grid = $('sportsGrid');
  if (!grid) return;
  const counts = {};
  achievements.forEach(a => counts[a.sport] = (counts[a.sport] || 0) + 1);
  grid.innerHTML = SPORTS.map(([name, icon]) => `
    <div class="sov-card" onclick="filterSport('${name.replace(/'/g,"\\'")}')">
      <div class="sov-icon">${icon}</div>
      <div class="sov-name">${escapeHtml(name)}</div>
      <div class="sov-count">${counts[name] || 0} achievement${counts[name] === 1 ? '' : 's'}</div>
    </div>`).join('');
}

function filterSport(sport) {
  $('flt_sport').value = sport;
  showPortalTab('view');
  searchAchievements();
}

function resetSearch() {
  ['flt_name','flt_class'].forEach(id => $(id).value = '');
  $('flt_sport').value = '';
  $('flt_level').value = '';
  searchAchievements();
}

async function loadAchievements(params = {}) {
  const qs = new URLSearchParams();
  Object.entries(params).forEach(([k,v]) => { if (v) qs.set(k,v); });
  const data = await api(`/achievements${qs.toString() ? `?${qs}` : ''}`);
  achievements = data.data || [];
  return achievements;
}

async function searchAchievements() {
  const container = $('achContainer');
  if (!container) return;
  container.innerHTML = '<div class="spinner-wrap"><div class="spinner"></div></div>';
  try {
    const rows = await loadAchievements({
      student_name: $('flt_name').value.trim(),
      sport: $('flt_sport').value,
      level: $('flt_level').value,
      class: $('flt_class').value.trim()
    });
    renderAchievements(rows);
    renderSportsGrid();
  } catch (err) {
    container.innerHTML = `<div class="empty-state"><div class="empty-icon">⚠️</div><p>${escapeHtml(err.message)}</p></div>`;
  }
}

function groupAchievements(rows) {
  const map = new Map();
  rows.forEach(row => {
    const key = row.roll_number;
    if (!map.has(key)) map.set(key, {student_name: row.student_name, roll_number:key, class:row.class, batch_year:row.batch_year, rows:[]});
    map.get(key).rows.push(row);
  });
  return [...map.values()];
}

function renderAchievements(rows) {
  const container = $('achContainer');
  if (!rows.length) {
    container.innerHTML = '<div class="empty-state"><div class="empty-icon">🏆</div><p>No achievements found.<br>Try changing your filters or add a new achievement.</p></div>';
    return;
  }
  container.innerHTML = groupAchievements(rows).map((student, index) => {
    const initials = escapeHtml(student.student_name.split(/\s+/).map(x=>x[0]).join('').slice(0,2).toUpperCase());
    const sports = [...new Set(student.rows.map(r=>r.sport))];
    return `<div class="student-card" data-index="${index}">
      <div class="student-header" onclick="toggleStudentCard(this.parentElement)">
        <div class="student-left">
          <div class="student-av">${initials}</div>
          <div class="student-info">
            <div class="student-name">${escapeHtml(student.student_name)}</div>
            <div class="student-meta"><span>🎓 ${escapeHtml(student.roll_number)}</span><span>📚 ${escapeHtml(student.class)}</span>${student.batch_year ? `<span>🗓 ${escapeHtml(student.batch_year)}</span>` : ''}</div>
            <div class="sport-pills-mini">${sports.map(s=>`<span class="spm">${escapeHtml(s)}</span>`).join('')}</div>
          </div>
        </div>
        <div class="student-right"><span class="ach-count-badge">${student.rows.length} record${student.rows.length===1?'':'s'}</span><span class="expand-arrow">▼</span></div>
      </div>
      <div class="ach-list">${student.rows.map(renderAchievementItem).join('')}</div>
    </div>`;
  }).join('');
}

function renderAchievementItem(a) {
  return `<div class="ach-item">
    <div class="ach-item-top">
      <div class="ach-item-left">
        <div class="ach-item-title">${escapeHtml(a.achievement)}</div>
        ${a.description ? `<div class="ach-item-desc">${escapeHtml(a.description)}</div>` : ''}
      </div>
      <div class="ach-item-actions">
        <button class="btn-edit" type="button" onclick="event.stopPropagation();openEditModal(${Number(a.id)})">EDIT</button>
        <button class="btn-delete" type="button" onclick="event.stopPropagation();deleteAchievement(${Number(a.id)})">DELETE</button>
      </div>
    </div>
    <div class="ach-tags">
      <span class="sport-pill-sm">🏆 ${escapeHtml(a.sport)}</span>
      <span class="mtag pos">🏅 ${escapeHtml(a.position || 'Participant')}</span>
      <span class="mtag lvl">📈 ${escapeHtml(a.level)}</span>
      ${a.category ? `<span class="mtag dt">👥 ${escapeHtml(a.category)}</span>` : ''}
      ${a.event_name ? `<span class="mtag dt">📍 ${escapeHtml(a.event_name)}</span>` : ''}
      ${a.event_date ? `<span class="mtag dt">📅 ${escapeHtml(formatDate(a.event_date))}</span>` : ''}
      ${a.score ? `<span class="mtag scr">⭐ ${escapeHtml(a.score)}</span>` : ''}
    </div>
    ${a.updated_at ? `<div class="ach-ts">Updated ${escapeHtml(formatDateTime(a.updated_at))}</div>` : ''}
  </div>`;
}
function formatDateTime(value) {
  const d = new Date(String(value).replace(' ','T') + (String(value).includes('Z') ? '' : 'Z'));
  return Number.isNaN(d.getTime()) ? value : d.toLocaleString(undefined,{day:'2-digit',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit'});
}

function formatDate(value) {
  if (!value) return '';
  const d = new Date(`${value}T00:00:00`);
  return Number.isNaN(d.getTime()) ? value : d.toLocaleDateString(undefined, {day:'2-digit',month:'short',year:'numeric'});
}

function toggleStudentCard(card) {
  if (card) card.classList.toggle('open');
}

function getAchievementForm(prefix='f') {
  return {
    student_name: $(`${prefix}_name`).value.trim(),
    roll_number: $(`${prefix}_roll`).value.trim().toUpperCase(),
    batch_year: $(`${prefix}_batch`).value,
    class: $(`${prefix}_class`).value.trim(),
    sport: $(`${prefix}_sport`).value,
    category: $(`${prefix}_category`).value,
    achievement: $(`${prefix}_achievement`).value.trim(),
    position: $(`${prefix}_position`).value,
    score: $(`${prefix}_score`).value.trim(),
    event_name: $(`${prefix}_event`).value.trim(),
    event_date: $(`${prefix}_date`).value,
    level: $(`${prefix}_level`).value,
    description: $(`${prefix}_desc`).value.trim()
  };
}

function validateAchievementForm(b) {
  const required = ['student_name','roll_number','batch_year','class','sport','category','achievement','level'];
  const missing = required.find(k => !b[k]);
  if (missing) return `${missing.replaceAll('_',' ')} is required.`;
  if (!/^[A-Z0-9]{15}$/.test(b.roll_number)) return 'Registration number must be exactly 15 letters/numbers.';
  if (b.student_name.length < 2 || b.student_name.length > 100) return 'Student name must be 2–100 characters.';
  if (b.achievement.length < 2 || b.achievement.length > 300) return 'Achievement must be 2–300 characters.';
  return '';
}

function clearAchievementForm(prefix='f') {
  ['name','roll','batch','class','level','sport','category','achievement','position','score','event','date','desc'].forEach(k => {
    const el = $(`${prefix}_${k}`);
    if (el) el.value = '';
  });
  onSportChange();
}

async function submitAchievement() {
  const b = getAchievementForm('f');
  const error = validateAchievementForm(b);
  if (error) { $('formStatus').textContent = error; showToast(error,true); return; }
  const button = document.querySelector('#psec-entry .btn-primary');
  setBusy(button,true);
  $('formStatus').textContent = 'Saving…';
  try {
    await api('/achievements', {method:'POST', body:JSON.stringify(b)});
    clearAchievementForm();
    $('formStatus').textContent = 'Saved successfully.';
    showToast('Achievement recorded!');
    await Promise.allSettled([loadStats(), searchAchievements()]);
  } catch (err) {
    $('formStatus').textContent = err.message;
    showToast(err.message,true);
  } finally { setBusy(button,false); }
}

function populateEdit(a) {
  const map = {
    edit_id:a.id,e_name:a.student_name,e_roll:a.roll_number,e_batch:a.batch_year,e_class:a.class,
    e_level:a.level,e_sport:a.sport,e_category:a.category,e_achievement:a.achievement,e_position:a.position,
    e_score:a.score,e_event:a.event_name,e_date:a.event_date,e_desc:a.description
  };
  Object.entries(map).forEach(([id,v]) => { if ($(id)) $(id).value = v ?? ''; });
  onEditSportChange();
}

function openEditModal(id) {
  const a = achievements.find(x => Number(x.id) === Number(id));
  if (!a) { showToast('Achievement is no longer available.',true); return; }
  populateEdit(a);
  $('editModal').classList.add('open');
  document.body.style.overflow = 'hidden';
}

function closeEditModal() {
  $('editModal').classList.remove('open');
  document.body.style.overflow = '';
}

async function saveEdit() {
  const id = Number($('edit_id').value);
  const b = {
    student_name:$('e_name').value.trim(), roll_number:$('e_roll').value.trim().toUpperCase(),
    batch_year:$('e_batch').value, class:$('e_class').value.trim(), level:$('e_level').value,
    sport:$('e_sport').value, category:$('e_category').value, achievement:$('e_achievement').value.trim(),
    position:$('e_position').value, score:$('e_score').value.trim(), event_name:$('e_event').value.trim(),
    event_date:$('e_date').value, description:$('e_desc').value.trim()
  };
  const error = validateAchievementForm(b);
  if (error) { showToast(error,true); return; }
  const button = document.querySelector('#editModal .btn-primary');
  setBusy(button,true);
  try {
    await api(`/achievements/${id}`, {method:'PUT', body:JSON.stringify(b)});
    closeEditModal();
    showToast('Achievement updated!');
    await Promise.allSettled([loadStats(), searchAchievements()]);
  } catch (err) { showToast(err.message,true); }
  finally { setBusy(button,false); }
}

async function deleteAchievement(id) {
  if (!window.confirm('Delete this achievement permanently?')) return;
  try {
    await api(`/achievements/${Number(id)}`, {method:'DELETE'});
    showToast('Achievement deleted.');
    await Promise.allSettled([loadStats(), searchAchievements()]);
  } catch (err) { showToast(err.message,true); }
}

function onSportChange() {
  const sport = $('f_sport')?.value;
  if ($('scoreLbl')) $('scoreLbl').textContent = sport === 'Cricket' ? 'Score / Result' : 'Score / Result';
}
function onEditSportChange() {
  const sport = $('e_sport')?.value;
  if ($('eScoreLbl')) $('eScoreLbl').textContent = sport === 'Cricket' ? 'Score / Result' : 'Score / Result';
}

document.addEventListener('keydown', e => {
  if (e.key === 'Escape' && $('editModal')?.classList.contains('open')) closeEditModal();
});
document.addEventListener('click', e => {
  if (e.target === $('editModal')) closeEditModal();
});

document.addEventListener('DOMContentLoaded', restoreSession);

Object.assign(window, {
  goto, showPortalTab, togglePw, updateRegCounter, validateEmailLive, checkStrength,
  createAccount, doLogin, logout, filterSport, resetSearch, searchAchievements,
  toggleStudentCard, submitAchievement, openEditModal, closeEditModal, saveEdit,
  deleteAchievement, onSportChange, onEditSportChange
});
